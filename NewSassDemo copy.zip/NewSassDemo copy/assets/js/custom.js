/* header js start */

(function($) { "use strict";

	$(function() {
		var header = $(".start-style");
		$(window).scroll(function() {    
			var scroll = $(window).scrollTop();
		
			if (scroll >= 10) {
				header.removeClass('start-style').addClass("scroll-on");
			} else {
				header.removeClass("scroll-on").addClass('start-style');
			}
		});
	});		

	$(document).ready(function() {
		$('body.hero-anime').removeClass('hero-anime');
	});
	$('body').on('mouseenter mouseleave','.nav-item',function(e){
			if ($(window).width() > 750) {
				var _d=$(e.target).closest('.nav-item');_d.addClass('show');
				setTimeout(function(){
				_d[_d.is(':hover')?'addClass':'removeClass']('show');
				},1);
			}
	});	
	
  })(jQuery);

/* header js end */

/*main slider js start*/

$('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    dots:false,
	nav:true,
	arrows:true,
    mouseDrag:false,
    autoplay:true,
    /*animateOut: 'slideOutUp',*/
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
});
/*main slider js end*/

/*generic-carousel slider js start*/  
$(".generic-carousel").owlCarousel({
	navigation: true,
	slideSpeed: 300,
	paginationSpeed: 400,
	animateOut: 'slideOutLeft',
	singleItem: true,
	responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
});
/*generic-carousel slider js end*/

/*our-projects js start*/
$('.folio-project').on('click', function() {
	var href = $(this).attr('href');
	if ($('#ajax').is(':visible')) {
		$('#ajax').css({ display:'block' }).animate({ height:'0' }).hide().slideUp('slow');
	}
	$('#ajax').html('');
	
	$('#ajax').show(0).animate({ height:'1200px' }, 500 ,function() {
		$('#ajax').load(href, function() {
			$('#ajax').css('height','auto');
			$("html, body").animate({ scrollTop: $('#ajax').offset().top }, 300);
		});
	});
});

/*our-projects js end*/

/*client logo slider js start */

$('#slick1').slick({
	rows: 2,
	dots: false,
	arrows: true,
	infinite: true,
	autoplay: true,
	speed: 1000,
	slidesToShow: 5,
	slidesToScroll: 1,
	responsive: [
		{
			breakpoint: 1025,
			settings: {
			  slidesToShow: 4,
			  slidesToScroll: 1,
			  infinite: true,
			  dots: false,
			  arrows:true
			}
		  },
		{
		  breakpoint: 992,
		  settings: {
			slidesToShow: 3,
			slidesToScroll: 1,
			infinite: true,
			dots: false,
			arrows:true
		  }
		},
		{
		  breakpoint: 480,
		  settings: {
			slidesToShow: 1,
			slidesToScroll: 1,
			arrows:true
		  }
		}		
	  ]
});

/*client logo slider js end */ 