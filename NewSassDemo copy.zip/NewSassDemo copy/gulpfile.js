var gulp = require('gulp');
var sass = require('gulp-sass');
var concat = require('gulp-concat');
var browserSync = require('browser-sync').create();
var changed = require('gulp-changed');
var imagemin = require('gulp-imagemin');
var jshint = require('gulp-jshint'); 
var uglify = require('gulp-uglify');

/* SASS files compilor task */
gulp.task('sass', function() {
    return gulp.src('assets/sass/**/*.scss')
        .pipe(sass({outputStyle: 'compact'}).on('error', sass.logError))
        .pipe(gulp.dest('assets/css'))
        .pipe(browserSync.stream());
});

/* Images minigy task*/
gulp.task('imagemin', function() {
    var imgSrc = 'dist/images-raw/**/*',
        imgDst = 'assets/img';
    gulp.src(imgSrc)
        .pipe(changed(imgDst))
        .pipe(imagemin())
        .pipe(gulp.dest(imgDst))
        .pipe(browserSync.stream());
});

gulp.task('pack-js', function () {    
    return gulp.src(['assets/js/vendor.min.js', 'assets/js/custom.js'])
        .pipe(concat('bundle.js'))
        .pipe(uglify())
        .pipe(gulp.dest('assets/js/bundle'));
});

/* Jshint task */
gulp.task('jshint', function() {
    return gulp.src('assets/js/*.js')
        .pipe(jshint())
        .pipe(jshint.reporter('default'));
});

/* Watch Task */
gulp.task('serve', ['sass'], function() {
    browserSync.init({
        server: "./"
    });
    gulp.watch("assets/sass/**/*.scss", ['sass']);
    gulp.watch("*.html").on('change', browserSync.reload);
    gulp.watch("assets/js/*.js").on('change', browserSync.reload);
    gulp.watch('assets/images-raw/*', ['imagemin']);
});

gulp.task('default', ['serve','jshint','imagemin','pack-js']);