Follow the steps to create SCSS with commandline :-

Required global in local machine
- node version 8 to 10
- gulp 

- check node version in command line type 'node -v'
- check gulp version in command line type 'gulp -v'

- step1 From command line goto current project root folder
- step2 npm install
- step3 gulp  